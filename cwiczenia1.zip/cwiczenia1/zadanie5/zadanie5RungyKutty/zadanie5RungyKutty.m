close all
clear
clc
nfontslatex = 18;
nfonts = 14;

%okreslenie pradu i napiecia w obwodzie
volC = @(t) 2*exp(-t)-2*(1+t).*exp(-2*t);
cirCurr = @(t) -exp(-t)+(1+2*t).*exp(-2*t);
tInit = 0.0;
tFinal = 5.0;

figure % plots of voltage and current
T = 0.01;
t = tInit:T:tFinal;
plot(t,volC(t),'r',t,cirCurr(t),'b','LineWidth', 2.0)
set(gca,'FontSize',nfonts);
xlabel('$t$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$v_{{\rm c}},i$','Interpreter','Latex','FontSize',nfontslatex)
grid on
legend({'$v_{{\rm c}}$','$i$'},'Interpreter','Latex','FontSize',nfontslatex,'Location','NorthEast')
print('voltageAndCurrentPlotsRK.eps','-depsc','-r600')
print('voltageAndCurrentPlotsRK.jpg','-djpeg','-r600')
print('voltageAndCurrentPlotsRK.pdf','-dpdf','-r600')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% parametry funkcji badanej
R = 3.0; L = 1.0; C=0.5;
A = [0 1/C; -1/L -R/L];
B = [0; 1/L];
u = @(t) exp(-2*t);
f = @(t,x) A*x+B*u(t);
xInit = [0; 0];

% skok T=0.1
T1 = 0.1; % integration step size
t1 = tInit:T1:tFinal;
N = length(t1);
X = zeros(2,N);
X(:,1) = xInit;

%Rungy-Kutty
for k=1:N-1
    dx1 = T1*f(t1(k),X(:,k));
    dx2 = T1*f(t1(k)+T1/2,X(:,k)+dx1/2);
    dx3 = T1*f(t1(k)+T1/2,X(:,k)+dx2/2);
    dx4 = T1*f(t1(k)+T1,X(:,k)+dx3);
    X(:,k+1)= X(:,k) + (dx1+2*dx2+2*dx3+dx4)/6;
end
%obliczanie rms
rmsv1 = rms(X(1,:)-volC(t1),2)
rmsi1 = rms(X(2,:)-cirCurr(t1),2)


% skok T=0.2
T2 = 0.2; % integration step size
t2 = tInit:T2:tFinal;
N = length(t2);
X = zeros(2,N);
X(:,1) = xInit;

%Rungy-Kutty
for k=1:N-1
    dx1 = T2*f(t2(k),X(:,k));
    dx2 = T2*f(t2(k)+T2/2,X(:,k)+dx1/2);
    dx3 = T2*f(t2(k)+T2/2,X(:,k)+dx2/2);
    dx4 = T2*f(t2(k)+T2,X(:,k)+dx3);
    X(:,k+1)= X(:,k) + (dx1+2*dx2+2*dx3+dx4)/6;
end
%obliczanie rms
rmsv2 = rms(X(1,:)-volC(t2),2)
rmsi2 = rms(X(2,:)-cirCurr(t2),2)