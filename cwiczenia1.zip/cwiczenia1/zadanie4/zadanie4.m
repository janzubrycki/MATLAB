clear
close all
clc 
nfontslatex = 18;
nfonts = 14;

tInit = -10;
tInside = 0;
tFinish = 2;
%pierwsze warunki poczatkowe
xInit1 = [1/(3^(2/3)*gamma(2/3));-1/(3^(1/3)*gamma(1/3))];
%drugie warunki poczatkowe
xInit2 = [1/(3^(1/6)*gamma(2/3));3^(1/6)/(gamma(1/3))];

%układ równań pierwszego rzędu
f = @(t,y) [y(2);t*y(1)];

%ode45 dla pierwszych warunkow poczatkowych
[t1,X1] = ode45(f,[tInside,tInit],xInit1);
[t2,X2] = ode45(f,[tInside,tFinish],xInit1);

%ode45 dla drugich warunkow poczatkowych
[t3,X3] = ode45(f,[tInside,tInit],xInit2);
[t4,X4] = ode45(f,[tInside,tFinish],xInit2);

%wykres dla warunków początkowych pierwszych
figure
plot(t1,X1(:,1),'r','LineWidth',2.0)
hold on
grid on
plot(t2,X2(:,1),'r','LineWidth',2.0)
hold on
grid on

%zakres wartosci na osi OY
ylim([-1,1]);

set(gca,'FontSize',nfonts)
xlabel('$t$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Ai(t)$','Interpreter','Latex','FontSize',nfontslatex)
legend({'$Ai(t)$'},'Interpreter','Latex','FontSize',nfontslatex,'Location','Best')
print('VDP41.eps','-depsc','-r600')
print('VDP41.jpg','-djpeg','-r600')
print('VDP41.pdf','-dpdf','-r600')

%wykres dla warunków początkowych drugich
figure 
plot(t3,X3(:,1),'b','LineWidth',2.0)
hold on
grid on
plot(t4,X4(:,1),'b','LineWidth',2.0)
hold on
grid on

ylim([-1,1]);

set(gca,'FontSize',nfonts)
xlabel('$t$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Bi(t)$','Interpreter','Latex','FontSize',nfontslatex)
legend({'$Bi(t)$'},'Interpreter','Latex','FontSize',nfontslatex,'Location','Best')
print('VDP42.eps','-depsc','-r600')
print('VDP42.jpg','-djpeg','-r600')
print('VDP42.pdf','-dpdf','-r600')

% laczna charakterystyka 
figure 
plot(t1,X1(:,1),'r','LineWidth',2.0)
hold on
grid on
plot(t2,X2(:,1),'r','LineWidth',2.0)
hold on
grid on
plot(t3,X3(:,1),'b','LineWidth',2.0)
hold on
grid on
plot(t4,X4(:,1),'b','LineWidth',2.0)
hold on
grid on
ylim([-1,1]);

set(gca,'FontSize',nfonts)
xlabel('$t$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Ai(t),\,Bi(t)$','Interpreter','Latex','FontSize',nfontslatex)
legend({'$Ai(t)$','','$Bi(t)$'},'Interpreter','Latex','FontSize',nfontslatex,'Location','Best')
print('VDP43.eps','-depsc','-r600')
print('VDP43.jpg','-djpeg','-r600')
print('VDP43.pdf','-dpdf','-r600')

%sprawdzenie funkcja airego
t = tInit:0.01:tFinish;
ai = airy(t);
bi = airy(2,t);
figure
plot(t,ai,'r',t,bi,'b','LineWidth',2.0)
grid on
ylim([-1,1]);

set(gca,'FontSize',nfonts)
xlabel('$t$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Ai(t),Bi(t)$','Interpreter','Latex','FontSize',nfontslatex)
legend({'$Ai(t)$','$Bi(t)$'},'Interpreter','Latex','FontSize',nfontslatex,'Location','Best')
print('VDP44.eps','-depsc','-r600')
print('VDP44.jpg','-djpeg','-r600')
print('VDP44.pdf','-dpdf','-r600')
