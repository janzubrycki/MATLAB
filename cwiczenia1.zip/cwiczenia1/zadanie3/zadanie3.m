clear
close all
clc
nfontslatex = 18;
nfonts = 14;

A = [-1,1;-1,-0.5];
B = [1;1];
tInit = 0.0;
tFinal = 10.0;
xInit = [0; 0];
% wymuszenia: u1 - skok jednostkowy; u2 - wymuszenie sinusoidalne
u1 = @(t) 1;
u2 = @(t) sin(t);
% rownania ukladu dynamicznego 
f1 = @(t,x) A*x + B*u1(t);
f2 = @(t,x) A*x + B*u2(t);
[t1,X1] = ode45(f1,[tInit,tFinal],xInit);
[t2,X2] = ode45(f2,[tInit,tFinal],xInit);

%sprawdzenie stabilnosci ukladu funkcja eig
eig(A)
% czesc rzeczywista obu skladowych wyniku jest mniejsza od zera, wiec mozna
% zalozyc stabilnosc ukladu


% wykres wartosci zmiennych stanu dla wymuszenia jednostkowego
figure
plot(t1,X1(:,1),'r','LineWidth',2.0)
hold on
grid on
plot(t1,X1(:,2),'b','LineWidth',2.0)
hold on 
grid on

set(gca,'FontSize',nfonts)
xlabel('$t$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$x_{1},\,x_{2}$','Interpreter','Latex','FontSize',nfontslatex)
legend({'$x_{1}$','$x_{2}$'},'Interpreter','Latex','FontSize',nfontslatex,'Location','Best')
print('VDP31.eps','-depsc','-r600')
print('VDP31.jpg','-djpeg','-r600')
print('VDP31.pdf','-dpdf','-r600')
%wykres wartosci zmiennych stanu dla wymuszenia sinusoidalnego 
figure
plot(t2,X2(:,1),'r','LineWidth',2.0)
hold on
grid on
plot(t2,X2(:,2),'b','LineWidth',2.0)
hold on 
grid on

set(gca,'FontSize',nfonts)
xlabel('$t$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$x_{1},\,x_{2}$','Interpreter','Latex','FontSize',nfontslatex)
legend({'$x_{1}$','$x_{2}$'},'Interpreter','Latex','FontSize',nfontslatex,'Location','Best')
print('VDP32.eps','-depsc','-r600')
print('VDP32.jpg','-djpeg','-r600')
print('VDP32.pdf','-dpdf','-r600')

%trajektoria stanu dla wymuszenia w postaci skoku jednostkowego
figure

plot(X1(:,1),X1(:,2),'r','LineWidth',2.0)
set(gca,'FontSize',nfonts)
xlabel('$x_{1}$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$x_{2}$','Interpreter','Latex','FontSize',nfontslatex)

print('VDP33.eps','-depsc','-r600')
print('VDP33.jpg','-djpeg','-r600')
print('VDP33.pdf','-dpdf','-r600')
