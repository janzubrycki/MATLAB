clear
close all
clc 
nfontslatex = 18;
nfonts = 14;

fS = 10; %czestotliowsc probkowania
fN = 5; %czestotliowsc Nyquista
TS = 0.1; %okres probkowania
wN = 2*fN*pi; %omega dla czestotliowsci Nyquista

w = 10^(-2):0.01:wN; %zbior zmiennych omega
f0 = @(w) (0.0045*exp(-w*1i*TS)+0.0041*exp(-2*w*1i*TS))/(1-1.7322*exp(-w*1i*TS)+0.7408*exp(-2*w*1i*TS));
wartosci = arrayfun(f0,w); %tablica wartosci funkcji f0

f1 = @(x) abs(x); 
moduly = arrayfun(f1,wartosci); %tablica modulow wartosci funkcji f0

f2 = @(y) 20*log10(y);
logarytmy = arrayfun(f2,moduly); %tablica wartosci na osi Y charakterystyki amplitudowej

f3 = @(z) angle(z);
argumenty = arrayfun(f3,wartosci); %tablica wartosci na osi Y charakterystyki fazowej

%charakterystyka amplitudowa 
figure
semilogx(w,logarytmy,'k','LineWidth',2.0)
hold on 
grid on
ylim([-80, 0])
%czerwone linie na charakterystyce
y = ylim;
semilogx([wN wN],[y(1) y(2)],'r','LineWidth',2.0)
hold on 
grid on
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Magnitude (dB)$','Interpreter','Latex','FontSize',nfontslatex)
print('amplitudowa1.jpg','-djpeg','-r600')

%charakterystyka fazowa 
figure
semilogx(w,(180/pi)*unwrap(argumenty),'k','LineWidth',2.0)
hold on
grid on
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Phase (deg)$','Interpreter','Latex','FontSize',nfontslatex)
ylim([-300,0]);
y = ylim;
semilogx([wN wN],[y(1) y(2)],'r','LineWidth',2.0 )
hold on 
grid on
print('fazowa1.jpg','-djpeg','-r600')


