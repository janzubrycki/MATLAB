clear
close all
clc 

nfontslatex = 18;
nfonts = 14;

%dobór współczynników dla transmitancji
T1 = 1;
T2 = 3;
TL = 2;
E = 3;

%obliczenia dla transmitancji A
%reprezentacja modelu w przestrzeni stanu dla transmitancji A
Ac = [0,1;-1,-3];
Bc = [0;1];
Cc = [1,0];
Dc = 0;
I = [1,0;0,1]; %macierz jednostkowa
Ts = 0.1; %okres próbkowania 
eig(Ac) %wyznaczenie wartości własnych macierzy Ac, w celu sprawdzenia czy macierz Ac jest macierzą Hurwitza
fprintf('Macierz Ac jest macierzą Hurwitza, ponieważ części rzeczywiste jej wartości własnych są ujemne')
fprintf('\n\nRównanie transmitancji A')
syms s
Gc = Cc*(inv(I*s-Ac))*Bc %Równanie transmitancji A z czasem ciągłym
fprintf('\nModel w przestrzeni stanu transmitancji A')
sysc = ss(Ac,Bc,Cc,Dc)

% Odpowiednik dyskretny modelu w przestrzeni stanu transmitancji A
%reprezentacja modelu w przestrzeni stanu dla transmitancji A
Ad = expm(Ac*Ts);
Bd = (inv(Ac))*((expm(Ac*Ts))-I)*Bc;
Cd = Cc;
Dd = 0;

fprintf('Transmitancja układu A z czasem dyskretnym ze wzoru')
syms z
H = Cd*(inv(I*z-Ad))*Bd %Równanie transmitancji A z czasem dyskretnym
fprintf('Obliczanie transmitancji układu A z czasem dyskretnym przy użyciu funckji systemowych\nWspółczynniki licznika (b) i mianownika (a)')
[bd,ad] = ss2tf(Ad,Bd,Cd,Dd)
z = tf('z',Ts);
Gd = tf(bd,ad,Ts,z) %transmitancja A dla czasu dyskretnego

% Odpowiednik dyskretny modelu w przestrzeni stanu transmitancji A 
fprintf('\n\nOdpowiednik dyskretny modelu w przestrzeni stanu transmitancji A')
sysd = ss(Ad,Bd,Cd,Dd,Ts)

