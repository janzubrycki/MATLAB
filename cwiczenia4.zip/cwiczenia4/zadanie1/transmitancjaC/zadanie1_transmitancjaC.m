clear
close all
clc 

nfontslatex = 18;
nfonts = 14;

%dobór współczynników dla transmitancji
T1 = 1;
T2 = 3;
TL = 2;
E = 3;

%obliczenia dla transmitancji C
%reprezentacja modelu w przestrzeni stanu dla transmitancji C
Ac = [0,1;-1,-2];
Bc = [0;1];
Cc = [1,2];
Dc = 0;
I = [1,0;0,1]; %macierz jednostkowa
Ts = 0.1; %okres próbkowania 
eig(Ac) %wyznaczenie wartości własnych macierzy Ac, w celu sprawdzenia czy macierz Ac jest macierzą Hurwitza
fprintf('Macierz Ac jest macierzą Hurwitza, ponieważ części rzeczywiste jej wartości własnych są ujemne')
fprintf('\n\nRównanie transmitancji C')
syms s
Gc = Cc*(inv(I*s-Ac))*Bc %Równanie transmitancji C z czasem ciągłym
fprintf('\nModel w przestrzeni stanu transmitancji C')
sysc = ss(Ac,Bc,Cc,Dc)

% Odpowiednik dyskretny modelu w przestrzeni stanu transmitancji C
%reprezentacja modelu w przestrzeni stanu dla transmitancji C
Ad = expm(Ac*Ts);
Bd = (inv(Ac))*((expm(Ac*Ts))-I)*Bc;
Cd = Cc;
Dd = 0;

fprintf('Transmitancja układu C z czasem dyskretnym ze wzoru')
syms z
H = Cd*(inv(I*z-Ad))*Bd %Równanie transmitancji C z czasem dyskretnym
fprintf('Obliczanie transmitancji układu C z czasem dyskretnym przy użyciu funckji systemowych\nWspółczynniki licznika (b) i mianownika (a)')
[bd,ad] = ss2tf(Ad,Bd,Cd,Dd)
z = tf('z',Ts);
Gd = tf(bd,ad,Ts,z) %transmitancja C dla czasu dyskretnego

% Odpowiednik dyskretny modelu w przestrzeni stanu transmitancji C 
fprintf('\n\nOdpowiednik dyskretny modelu w przestrzeni stanu transmitancji C')
sysd = ss(Ad,Bd,Cd,Dd,Ts)

