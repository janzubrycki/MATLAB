clear
close all
clc 

nfontslatex = 18;
nfonts = 14;

%dobór współczynników dla transmitancji
T1 = 1;
T2 = 3;
TL = 2;
E = 3;

%obliczenia dla transmitancji D
%reprezentacja modelu w przestrzeni stanu dla transmitancji D
Ac = [0,1;-1/3,-4/3];
Bc = [0;1];
Cc = [1/3,2/3];
Dc = 0;
I = [1,0;0,1]; %macierz jednostkowa
Ts = 0.1; %okres próbkowania 
eig(Ac) %wyznaczenie wartości własnych macierzy Ac, w celu sprawdzenia czy macierz Ac jest macierzą Hurwitza
fprintf('Macierz Ac jest macierzą Hurwitza, ponieważ części rzeczywiste jej wartości własnych są ujemne')
fprintf('\n\nRównanie transmitancji D')
syms s
Gc = Cc*(inv(I*s-Ac))*Bc %Równanie transmitancji D z czasem ciągłym
fprintf('\nModel w przestrzeni stanu transmitancji D')
sysc = ss(Ac,Bc,Cc,Dc)

% Odpowiednik dyskretny modelu w przestrzeni stanu transmitancji D
%reprezentacja modelu w przestrzeni stanu dla transmitancji D
Ad = expm(Ac*Ts);
Bd = (inv(Ac))*((expm(Ac*Ts))-I)*Bc;
Cd = Cc;
Dd = 0;

fprintf('Transmitancja układu D z czasem dyskretnym ze wzoru')
syms z
H = Cd*(inv(I*z-Ad))*Bd %Równanie transmitancji D z czasem dyskretnym
fprintf('Obliczanie transmitancji układu D z czasem dyskretnym przy użyciu funckji systemowych\nWspółczynniki licznika (b) i mianownika (a)')
[bd,ad] = ss2tf(Ad,Bd,Cd,Dd)
z = tf('z',Ts);
Gd = tf(bd,ad,Ts,z) %transmitancja D dla czasu dyskretnego

% Odpowiednik dyskretny modelu w przestrzeni stanu transmitancji D 
fprintf('\n\nOdpowiednik dyskretny modelu w przestrzeni stanu transmitancji D')
sysd = ss(Ad,Bd,Cd,Dd,Ts)

