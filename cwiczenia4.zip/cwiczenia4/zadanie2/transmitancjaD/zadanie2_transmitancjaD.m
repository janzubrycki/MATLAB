clear
close all
clc

nfontslatex = 18;
nfonts = 14;

%dobór współczynników dla transmitancji
T1 = 1;
T2 = 3;
TL = 2;
E = 3;

Ts = 0.1; %okres próbkowania
tInit = 0.0;
tFinal = 10.0;
xInit = [0;0];
I = [1,0;0,1]; %macierz jednostkowa

%Obliczenia dla czasu ciągłego
u = @(t) 1; %określenie skoku jednostkowego dla czasu dyskretnego 
%reprezentacja modelu w przestrzeni stanu dla transmitancji D
Ac = [0,1;-1/3,-4/3];
Bc = [0;1];
Cc = [1/3,2/3];

f = @(t,x) Ac*x+Bc*u(t);%równanie stanu
[t,X] = ode45(f,[tInit,tFinal],xInit);
y = X*Cc';

%Obliczenia dla czasu dyskretnego
%reprezentacja modelu w przestrzeni stanu dla transmitancji D
Ad = expm(Ac*Ts);
Bd = (inv(Ac))*((expm(Ac*Ts))-I)*Bc;
Cd = Cc; 

td = tInit:Ts:tFinal; %określenie przedziału czasu odpowiedzi dyskretnej z uwzględnieniem próbkowania co Ts=0.1

N = 100; %określenie liczby "prążków" odpowiedzi dyskretnej, określa ile razy spróbkujemy z okresem Ts=0.1 dla przedziału czasu odpowiedzi [tInit,tFinal]=10
n = 2; %ilość zmiennych stanu
U = ones(1, N); %okeślenie skoku jednostkowego dla czasu dyskretnego
N = size(U,2);
X = zeros(n,N);
x0 = zeros(n,1);
x = x0;
for k = 1:N
x = Ad*x + Bd*U(:,k);
X(:,k) = x;
end
Y = Cd*[x0 X];

%odpowiedź skokowa dla czasu ciągłego
figure
plot(t,y,'k','LineWidth',2.0)
hold on
grid on

%odpowiedź skokowa dla czasu dyskretnego
stem(td,Y,'r','filled','LineWidth',1.0)
grid on 
hold on

print('odpowiedź_skokowa_transmitancjaD.jpg','-djpeg','-r600')


