clear
close all
clc

nfontslatex = 18;
nfonts = 14;

%dobór współczynników dla transmitancji
T1 = 1;
T2 = 3;
TL = 2;
E = 3;

Ts = 0.1; %okres probkowania
fs = 1/Ts; %częstotliwość próbkowania
fNY = 1/2*fs; %częstotliwość Nyquista
I = [1,0;0,1]; %macierz jednostkowa

%obliczenia dla czasu ciągłego 
w = 10^(-2):0.01:10^3; %określenie omegi dla czasu ciągłego
%reprezentacja modelu w przestrzeni stanu dla transmitancji A
Ac = [0,1;-1,-3];
Bc = [0;1];
Cc = [1,0];
Dc = 0;
%Transmitancja układu A z czasem ciągłym
syms s
Gc = Cc*(inv(I*s-Ac))*Bc
gc = @(s) 1./(s.^2+3.*s+1);


%Obliczenia dla czasu dyskretnego
%reprezentacja modelu w przestrzeni stanu dla transmitancji A
Ad = expm(Ac*Ts);
Bd = (inv(Ac))*((expm(Ac*Ts))-I)*Bc;
Cd = Cc;
Dd = 0;
%Transmitancja układu A z czasem dyskretnym
[bd,ad] = ss2tf(Ad,Bd,Cd,Dd);
z = tf('z',Ts);
Gd = tf(bd,ad,Ts,z)


n = 2; %ilość zmiennych stanu
m = 1; %ilość wejść
p = 1; %ilość wyjść

U = ones(1, n);
N = size(U,2);
X = zeros(n,N);
x0 = zeros(n,1);
x = x0;

for k = 1:N
    x = Ad*x + Bd*U(:,k);
    X(:,k) = x;
end

Y = Cd*[x0, X];

HH = @(z) Cd(1,:)/(eye(2)*z-Ad)*Bd;
wd = logspace(-2,log10(pi/Ts),500); %omega dla czasu dyskretnego
z = exp(1i*wd*Ts);
amplitudy = 20*log10(abs(arrayfun(HH,z)));
argumenty = (180/pi)*unwrap(angle(arrayfun(HH,z)));


%Charakterystyka amplitudowa

%dla czasu ciągłego
figure
subplot(2,1,1)
plot(w, 20*log10(abs(gc(1i.*w))), 'k','LineWidth',2.0)
set(gca,'FontSize',nfonts, 'XScale', 'log')
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Magnitude (dB)$','Interpreter','Latex','FontSize',nfontslatex)

grid on
hold on 

%dla czasu dyskretnego
semilogx(wd,amplitudy,'r','LineWidth',2)
set(gca,'FontSize',nfonts);
xlabel('Frequency (rad/s)','Interpreter','Latex','FontSize',nfontslatex)
ylabel('Magnitude (dB)','Interpreter','Latex','FontSize',nfontslatex)
xlim([10^(-2), 10^3])
xline(2*pi*fNY,'--k','LineWidth',2.0)
grid on



%Charakterystyka fazowa

%dla czasu ciągłego 
subplot(2,1,2)
plot(w, rad2deg(unwrap(angle(gc(1i*w)))),'k','LineWidth',2.0)
set(gca,'FontSize',nfonts, 'XScale', 'log')
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Phase (deg)$','Interpreter','Latex','FontSize',nfontslatex)
grid on
hold on 

%dla czasu dyskretnego
semilogx(wd,argumenty,'r','LineWidth',2)
set(gca,'FontSize',nfonts);
xlabel('Frequency (rad/s)','Interpreter','Latex','FontSize',nfontslatex)
ylabel('Phase (deg)','Interpreter','Latex','FontSize',nfontslatex)
xlim([10^(-2), 10^3])
ylim([-300,0])
xline(2*pi*fNY,'--k','LineWidth',2.0)
grid on
hold on

print('charakterystyki_Bodego_Ts0.1_transmitancjaA.jpg','-djpeg','-r600')


