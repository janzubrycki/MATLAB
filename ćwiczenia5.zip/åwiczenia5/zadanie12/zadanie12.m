clear
close all
clc 

nfontslatex = 18;
nfonts = 14;

fs=10000; %Częstotliwość przełączania
ws=2*pi*fs;
T=1/fs; %Czas trwania jednego cyklu
T1=T/2; %T1 i T2 jako czasy trwania faz przełączania układu
T2=T/2;
%Wartości elementów w obwodzie
R1=0;R2=0;R3=0;
R=9;
C=5.4*10^(-6);
L=180*10^(-6);
Vin=15;
Iout=1;

%Opis stanowy układu
A=[-(R1+R2)/L,0;0,-1/(C*(R+R3))];
B=[-(R3*(2*R+R3))/(L*(R+R3))+(R1+R2)/L,(R+2*R3)/(L*(R+R3));-R/(C*(R+R3)),0];
b=[R3*R*Iout/(L*(R+R3))-Vin/L;0];
f=[Vin/L;R*Iout/(C*(R+R3))];

A1=A;
A2=A+B;
B1=f;
B2=f+b;


u = @(t) (1-sign(sin(ws*t)))/2;

%Wyznaczanie fi
fi=expm(A2*T2)*expm(A1*T1);

%Wyznaczanie gamma
f1= @(t) expm(A1*(T1-t))*B1;
f2= @(t) expm(A2*(T2-t))*B2;
gamma=expm(A2*T2)*integral(f1,0,T1,'ArrayValued',true)+integral(f2,0,T2,'ArrayValued',true);

xss=inv(eye(2)-fi)*gamma;%warunek początkowy stanu ustalonego układu dyskretnego

%Funkcja (12) opisująca badany układ
f1 = @(t,x) A*x+B*x*u(t)+b*u(t)+f;
%Przedziały czasu
tInit=0;
tFinal=5*10^(-4);
%Zerowy warunek początkowy
xInit=[0,0];

td=tInit:T:tFinal; %Określenie czasu dyskretnego z próbkowaniem T, które odpowiada jednemu cyklowi

%Realizacja układu przy pomocy funkcji ode45 
options = odeset('RelTol',1e-14,'AbsTol',1e-14);
[t1,X1] = ode45(f1,[tInit,tFinal],xInit,options); %Pełen przedział czasu z zerowym warunkiem początkowym
[t2,X2] = ode45(f1,[tInit,T],xss,options); %Dla jednego cyklu w stanie ustalonym
[t3,X3] = ode45(f1,[tInit,tFinal],xss,options); %Pełen przedział czasu w stanie ustalonym
[t4,X4] = ode45(f1,[tInit,T1],xss,options); %Pierwsza cześć cyklu w stanie ustalonym
xInit2=X4(end,:); %Warunki początkowe w momencie rozpoczęcia drugiej połowy cyklu (końcowe wartości cyklu pierwszego)
[t5,X5] = ode45(f1,[T2,T],xInit2,options); %Druga część cyklu w stanie ustalonym


%Wyznaczanie kolejnych wartości przebiegu dyskretnego przy pomocy wzoru (8) z instrukcji
x0=0;
m=zeros(tFinal/T+1,1); %tFinal/T oznacza ilość upływów okresu w badanym przedziale czasowym, +1 jako wartość dla zerowego warunku początkowego 
m(1,1)=x0;
for k = 1:1:tFinal/T
    xi=fi*x0+gamma;
    x0=xi;
    m(k+1,1)=xi(1,1);
end

%Wyznaczanie kolejnych wartości przebiegu dyskretnego w stanie ustalonym przy pomocy wzoru (8) z instrukcji
x00=xss; %Wykorzystanie warunku początkowego dla układu dyskretnego
n=zeros(tFinal/T+1,1); %tFinal/T oznacza ilość upływów okresu w badanym przedziale czasowym, +1 jako wartość dla zerowego warunku początkowego 
n(1,1)=x00(1,1);
for k = 1:1:tFinal/T
    xi=fi*x00+gamma;
    x00=xi;
    n(k+1,1)=xi(1,1);
end


%Trajektoria stanu z zaznaczonym na czerwono cyklem w stanie ustalonym
figure
plot(X1(:,2),X1(:,1),'k','LineWidth',2.0)
hold on
grid on
plot(X2(:,2),X2(:,1),'r','LineWidth',2.0)
hold on
grid on
xlabel('$v (V)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$i (A)$','Interpreter','Latex','FontSize',nfontslatex)
print('Trajektoria stanu z zaznaczonym na czerwono cyklem w stanie ustalonym.jpg','-djpeg','-r600')

%Przebieg natężenia prądu i dławika w wersji ciągłej (czarna) i dyskretnej (czerwona)
figure
plot(t1,X1(:,1),'k','LineWidth',2.0)
hold on
grid on
stem(td,m(:,1),'r','filled','LineWidth',1.0)
grid on 
hold on
xlabel('$t (s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$i (A)$','Interpreter','Latex','FontSize',nfontslatex)
print('Przebieg natężenia prądu i dławika w wersji ciągłej (czarna) i dyskretnej (czerwona).jpg','-djpeg','-r600')

%Przebieg napięcia v na kondensatorze  w przedziale czasowym od 0 do 0.5ms
figure
plot(t1,X1(:,2),'k','LineWidth',2.0)
hold on
grid on
xlabel('$t (s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$v (V)$','Interpreter','Latex','FontSize',nfontslatex)
print('Przebieg napięcia v na kondensatorze  w przedziale czasowym od 0 do 0.5ms.jpg','-djpeg','-r600')
 
%Przebieg natężenia prądu dławika w stanie ustalonym
figure
plot(t3,X3(:,1),'k','LineWidth',2.0)
hold on
grid on
stem(td,n(:,1),'r','filled','LineWidth',1.0)
grid on 
hold on
xlabel('$t (s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$i (A)$','Interpreter','Latex','FontSize',nfontslatex)
print('Przebieg natężenia prądu dławika w stanie ustalonym','-djpeg','-r600')

%Trajektoria stanu dla jednego cyklu stanu ustalonego
figure
plot(X2(:,2),X2(:,1),'k','LineWidth',2.0)
hold on
grid on
xlabel('$v (V)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$i (A)$','Interpreter','Latex','FontSize',nfontslatex)
print('Trajektoria stanu dla jednego cyklu stanu ustalonego','-djpeg','-r600')

%Trajektoria stanu dla pierwszej części cyklu stanu ustalonego
figure
plot(X4(:,2),X4(:,1),'k','LineWidth',2.0)
hold on
grid on
xlabel('$v (V)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$i (A)$','Interpreter','Latex','FontSize',nfontslatex)
print('Trajektoria stanu dla pierwszej części cyklu stanu ustalonego','-djpeg','-r600')

%Trajektoria stanu dla drugiej części cyklu stanu ustalonego
figure
plot(X5(:,2),X5(:,1),'k','LineWidth',2.0)
hold on
grid on
xlabel('$v (V)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$i (A)$','Interpreter','Latex','FontSize',nfontslatex)
print('Trajektoria stanu dla drugiej części cyklu stanu ustalonego','-djpeg','-r600')




