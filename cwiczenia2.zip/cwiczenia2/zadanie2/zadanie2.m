clear
close all
clc 
nfontslatex = 18;
nfonts = 14;

u = @(t) 1;
tInit = 0.0;
tFinal = 10.0;
xInit = [0;0];
%obliczenia dla transmitancji A
A1 = [0,1;-1,-3];
B1 = [0;1];
C1 = [1,0];
f1 = @(t1,x1) A1*x1+B1*u(t1);
[t1,X1] = ode45(f1,[tInit,tFinal],xInit);
y1 = X1*C1';

figure
plot(t1,y1,'r','LineWidth',2.0)
hold on
grid on
print('skokowaA.eps','-depsc','-r600')
print('skokowaA.jpg','-djpeg','-r600')
print('skokowaA.pdf','-dpdf','-r600')

%obliczenia dla transmitancji B
A2 = [0,1;-1,-6];
B2 = [0;1];
C2 = [1,2];
f2 = @(t2,x2) A2*x2+B2*u(t2);
[t2,X2] = ode45(f2,[tInit,tFinal],xInit);
y2 = X2*C2';

figure
plot(t2,y2,'b','LineWidth',2.0)
hold on
grid on
print('skokowaB.eps','-depsc','-r600')
print('skokowaB.jpg','-djpeg','-r600')
print('skokowaB.pdf','-dpdf','-r600')

%obliczenia dla transmitancji C
A3 = [0,1;-1,-2];
B3 = [0;1];
C3 = [1,2];
f3 = @(t3,x3) A3*x3+B3*u(t3);
[t3,X3] = ode45(f3,[tInit,tFinal],xInit);
y3 = X3*C3';

figure
plot(t3,y3,'y','LineWidth',2.0)
hold on
grid on
print('skokowaC.eps','-depsc','-r600')
print('skokowaC.jpg','-djpeg','-r600')
print('skokowaC.pdf','-dpdf','-r600')

%obliczenia dla transmitancji D
A4 = [0,1;-1/3,-4/3];
B4 = [0;1];
C4 = [1/3,2/3];
f4 = @(t4,x4) A4*x4+B4*u(t4);
[t4,X4] = ode45(f4,[tInit,tFinal],xInit);
y4 = X4*C4';

figure
plot(t4,y4,'g','LineWidth',2.0)
hold on
grid on
print('skokowaD.eps','-depsc','-r600')
print('skokowaD.jpg','-djpeg','-r600')
print('skokowaD.pdf','-dpdf','-r600')