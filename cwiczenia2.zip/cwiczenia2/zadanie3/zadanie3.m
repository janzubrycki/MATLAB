clear
close all
clc 
nfontslatex = 18;
nfonts = 14;

%obliczenia dla transmitancji A
A1 = [0,1;-1,-3];
g1 = @(s) 1/(s^2+3*s+1);
sys1 = tf([1],[1,3,1]);
P1 = pole(sys1)
eig(A1)

%obliczenia dla transmitancji B
A2 = [0,1;-1,-6];
g2 = @(s) (1+2*s)/(s^2+6*s+1);
sys2 = tf([2 1],[1,6,1]);
P2 = pole(sys2)
eig(A2)

%obliczenia dla transmitancji C
A3 = [0,1;-1,-2];
g3 = @(s) (1+2*s)/(s^2+2*s+1);
sys3 = tf([2 1],[1,2,1]);
P3 = pole(sys3)
eig(A3)

%obliczenia dla transmitancji D
A4 = [0,1;-1/3,-4/3];
g4 = @(s) (1/3+(2/3)*s)/(s^2+(4/3)*s+1/3);
sys4 = tf([2/3 1/3],[1,4/3,1/3]);
P4 = pole(sys4)
eig(A4)

%Sa to uklady 2 rzedu, w kazdym z nich wspolczynniki w mianowniku sa
%dodatnie, wartosci wlasne macierzy A kazdego z ukladow sa rowne
%biegunom ich transmitancji. Zatem uklady te sa stabilne.
% Wszystkie uklady sa stabilne, maja dodatnie wspolczynniki w mianowniku,
% sa to rownania drugiego rzedu. Wartosci wlasne rowne sa biegunom transmitancji. 
