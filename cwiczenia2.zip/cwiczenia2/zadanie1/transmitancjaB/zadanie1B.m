clear
close all
clc 
nfontslatex = 18;
nfonts = 14;

%obliczenia dla transmitancji B
b1 = 10^(-2):0.01:10^3; %tablica zmiennych funkcji

f01 = @(w) (1+2*w*1i)/(-(w^2)+6*w*1i+1); %rownanie transmitancji B
wartosci1 = arrayfun(f01,b1); %tablica wynikow transmitancji

f11 = @(x) abs(x); 
moduly1 = arrayfun(f11,wartosci1); %tablica modulow wynikow transmitancji

f21 = @(y) 20*log10(y);
logarytmy1 = arrayfun(f21,moduly1); %tablica wartosci osiY charakterystyki amplitudowej 

f31 = @(z) angle(z)*180/pi;
argumenty1 = arrayfun(f31,wartosci1); %tablica wartosci osiY charakterystyki fazowej

%sprawdzenie charakterystyk funkcja bode
B = tf([2 1],[1 6 1]);
bode(B)

%charakterystyka amplitudowa B
figure
semilogx(b1,logarytmy1,'r','LineWidth',2.0)
hold on
grid on
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Magnitude (dB)$','Interpreter','Latex','FontSize',nfontslatex)
print('amplitudowaB.eps','-depsc','-r600')
print('amplitudowaB.jpg','-djpeg','-r600')
print('amplitudowaB.pdf','-dpdf','-r600')

%charakterystyka fazowa B
figure
semilogx(b1,argumenty1,'b','LineWidth',2.0)
hold on
grid on
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Phase (deg)$','Interpreter','Latex','FontSize',nfontslatex)
ylim([-200,0]);
print('fazowaB.eps','-depsc','-r600')
print('fazowaB.jpg','-djpeg','-r600')
print('fazowaB.pdf','-dpdf','-r600')