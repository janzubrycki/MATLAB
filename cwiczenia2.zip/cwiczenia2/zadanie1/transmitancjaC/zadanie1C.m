clear
close all
clc 
nfontslatex = 18;
nfonts = 14;

%obliczenia dla transmitancji C
b2 = 10^(-2):0.01:10^3; %tablica zmiennych funkcji

f02 = @(w) (1+2*w*1i)/(-(w^2)+2*w*1i+1); %rownanie transmitancji C
wartosci2 = arrayfun(f02,b2); %tablica wynikow transmitancji

f12 = @(x) abs(x); 
moduly2 = arrayfun(f12,wartosci2); %tablica modulow wynikow transmitancji

f22 = @(y) 20*log10(y);
logarytmy2 = arrayfun(f22,moduly2); %tablica wartosci osiY charakterystyki amplitudowej 

f32 = @(z) angle(z)*180/pi;
argumenty2 = arrayfun(f32,wartosci2); %tablica wartosci osiY charakterystyki fazowej

%sprawdzenie charakterystyk funkcja bode
C = tf([2 1],[1 2 1]);
bode(C)

%charakterystyka amplitudowa C
figure
semilogx(b2,logarytmy2,'r','LineWidth',2.0)
hold on
grid on
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Magnitude (dB)$','Interpreter','Latex','FontSize',nfontslatex)
print('amplitudowaC.eps','-depsc','-r600')
print('amplitudowaC.jpg','-djpeg','-r600')
print('amplitudowaC.pdf','-dpdf','-r600')

%charakterystyka fazowa C
figure
semilogx(b2,argumenty2,'b','LineWidth',2.0)
hold on
grid on
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Phase (deg)$','Interpreter','Latex','FontSize',nfontslatex)
ylim([-200,0]);
print('fazowaC.eps','-depsc','-r600')
print('fazowaC.jpg','-djpeg','-r600')
print('fazowaC.pdf','-dpdf','-r600')
