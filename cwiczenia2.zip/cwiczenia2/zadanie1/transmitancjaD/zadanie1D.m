clear
close all
clc 
nfontslatex = 18;
nfonts = 14;

%obliczenia dla transmitancji D
b3 = 10^(-2):0.01:10^3; %tablica zmiennych funkcji

f03 = @(w) (1/3+(2/3)*w*1i)/(-(w^2)+(4/3)*w*1i+1/3); %rownanie transmitancji D
wartosci3 = arrayfun(f03,b3); %tablica wynikow transmitancji

f13 = @(x) abs(x); 
moduly3 = arrayfun(f13,wartosci3); %tablica modulow wynikow transmitancji

f23 = @(y) 20*log10(y);
logarytmy3 = arrayfun(f23,moduly3); %tablica wartosci osiY charakterystyki amplitudowej 

f33 = @(z) angle(z)*180/pi;
argumenty3 = arrayfun(f33,wartosci3); %tablica wartosci osiY charakterystyki fazowej

%sprawdzenie charakterystyk funkcja bode
D = tf([2/3 1/3],[1 4/3 1/3]);
bode(D)

%charakterystyka amplitudowa D
figure
semilogx(b3,logarytmy3,'r','LineWidth',2.0)
hold on
grid on
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Magnitude (dB)$','Interpreter','Latex','FontSize',nfontslatex)
print('amplitudowaD.eps','-depsc','-r600')
print('amplitudowaD.jpg','-djpeg','-r600')
print('amplitudowaD.pdf','-dpdf','-r600')

%charakterystyka fazowa D
figure
semilogx(b3,argumenty3,'b','LineWidth',2.0)
hold on
grid on
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Phase (deg)$','Interpreter','Latex','FontSize',nfontslatex)
ylim([-200,0]);
print('fazowaD.eps','-depsc','-r600')
print('fazowaD.jpg','-djpeg','-r600')
print('fazowaD.pdf','-dpdf','-r600')