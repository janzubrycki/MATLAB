clear
close all
clc 
nfontslatex = 18;
nfonts = 14;

%obliczenia dla transmitancji A
b = 10^(-2):0.01:10^3; %tablica zmiennych funkcji

f0 = @(w) 1/(-(w^2)+3*w*1i+1); %rownanie transmitancji A
wartosci = arrayfun(f0,b); %tablica wynikow transmitancji

f1 = @(x) abs(x); 
moduly = arrayfun(f1,wartosci); %tablica modulow wynikow transmitancji

f2 = @(y) 20*log10(y);
logarytmy = arrayfun(f2,moduly); %tablica wartosci osiY charakterystyki amplitudowej 

f3 = @(z) angle(z)*180/pi;
argumenty = arrayfun(f3,wartosci); %tablica wartosci osiY charakterystyki fazowej

%sprawdzenie charakterystyk funkcja bode
A = tf([1],[1 3 1]);
bode(A)

%charakterystyka amplitudowa A
figure
semilogx(b,logarytmy,'r','LineWidth',2.0)
hold on
grid on
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Magnitude (dB)$','Interpreter','Latex','FontSize',nfontslatex)
print('amplitudowaA.eps','-depsc','-r600')
print('amplitudowaA.jpg','-djpeg','-r600')
print('amplitudowaA.pdf','-dpdf','-r600')

%charakterystyka fazowa A
figure
semilogx(b,argumenty,'b','LineWidth',2.0)
hold on
grid on
xlabel('$Frequency (rad/s)$','Interpreter','Latex','FontSize',nfontslatex)
ylabel('$Phase (deg)$','Interpreter','Latex','FontSize',nfontslatex)
ylim([-200,0]);
print('fazowaA.eps','-depsc','-r600')
print('fazowaA.jpg','-djpeg','-r600')
print('fazowaA.pdf','-dpdf','-r600')
